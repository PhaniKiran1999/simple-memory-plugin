import type { MemoryRecord } from "../types/MemoryRecord.js";

export class JsonMemoryStore {

    async load(): Promise<MemoryRecord[]> {
        return [];
    }

    async save(records: MemoryRecord[]): Promise<void> {
    }

    async search(query: string): Promise<MemoryRecord[]> {
        return [];
    }

}
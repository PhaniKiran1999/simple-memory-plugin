export interface MemoryRecord {
    id: string;
    text: string;
    createdAt: string;
    updatedAt?: string;
    tags?: string[];
}
import { definePluginEntry } from "openclaw/plugin-sdk/plugin-entry";
import { JsonMemoryRuntime } from "./runtime/JsonMemoryRuntime.js";

export default definePluginEntry({
    id: "simple-memory",

    name: "Simple Memory",

    description: "Simple JSON Memory backend.",

    register(api) {

        api.registerMemoryCapability({
            runtime: new JsonMemoryRuntime(api.logger)
        });

        api.logger.info("Simple Memory registered.");

    }
});
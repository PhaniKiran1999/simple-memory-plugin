import type {
    MemorySearchManager,
    MemorySearchResult,
    MemoryReadResult,
    MemoryProviderStatus,
    MemorySyncParams,
    MemorySearchRuntimeDebug,
} from "openclaw/plugin-sdk/memory-core-host-engine-storage";

import { JsonMemoryStore } from "../store/JsonMemoryStore.js";
import { PluginLogger } from "openclaw/plugin-sdk";

export class JsonMemorySearchManager
    implements MemorySearchManager {

    constructor(
        private readonly store: JsonMemoryStore,
        private readonly logger: PluginLogger
    ) {}
    getCachedEmbeddingAvailability?(): { ok: boolean; error?: string; checked?: boolean; cached?: boolean; checkedAtMs?: number; cacheExpiresAtMs?: number; } | null {
        this.logger.info("[JsonMemorySearchManager] getCachedEmbeddingAvailability");
        return null;
    }
    probeEmbeddingAvailability(): Promise<{ ok: boolean; error?: string; checked?: boolean; cached?: boolean; checkedAtMs?: number; cacheExpiresAtMs?: number; }> {
        this.logger.info("[JsonMemorySearchManager] probeEmbeddingAvailability");
        return Promise.resolve({
            ok: false,
            checked: true,
            checkedAtMs: Date.now(),
        });
    }
    probeVectorStoreAvailability?(): Promise<boolean> {
        this.logger.info("[JsonMemorySearchManager] probeVectorStoreAvailability");
        return Promise.resolve(false);
    }

    async search(
        query: string,
        opts?: {
            maxResults?: number;
            minScore?: number;
            sessionKey?: string;
            qmdSearchModeOverride?: "query" | "search" | "vsearch";
            onDebug?: (debug: MemorySearchRuntimeDebug) => void;
            signal?: AbortSignal;
        }
    ): Promise<MemorySearchResult[]> {
        this.logger.info("[JsonMemorySearchManager] search"+ { query, opts });

        return [];
    }

    async readFile(params: {
        relPath: string;
        from?: number;
        lines?: number;
    }): Promise<MemoryReadResult> {
        this.logger.info("[JsonMemorySearchManager] readFile"+ params);

        throw new Error("Not implemented");
    }

    status(): MemoryProviderStatus {
        this.logger.info("[JsonMemorySearchManager] status");

        throw new Error("Not implemented");

    }


    async probeVectorAvailability() {
        this.logger.info("[JsonMemorySearchManager] probeVectorAvailability");

        return false;

    }

    async sync(params?: MemorySyncParams): Promise<void> {
        this.logger.info("[JsonMemorySearchManager] sync"+ params);

    }

    async close(): Promise<void> {
        this.logger.info("[JsonMemorySearchManager] close");

    }

}

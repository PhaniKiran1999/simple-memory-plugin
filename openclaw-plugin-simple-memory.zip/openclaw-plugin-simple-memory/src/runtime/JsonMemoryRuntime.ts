import type {
    MemoryPluginRuntime,
    OpenClawConfig
} from "openclaw/plugin-sdk/memory-host-core";

import { JsonMemorySearchManager } from "./JsonMemorySearchManager.js";
import { JsonMemoryStore } from "../store/JsonMemoryStore.js";
import { MemorySearchManager } from "openclaw/plugin-sdk/memory-core-host-engine-storage";
import { PluginLogger } from "openclaw/plugin-sdk";

export class JsonMemoryRuntime
    implements MemoryPluginRuntime {

        constructor(
            private readonly logger: PluginLogger
        ) {}
    getMemorySearchManager(params: { cfg: OpenClawConfig; agentId: string; purpose?: "default" | "status" | "cli"; }): Promise<{ manager: MemorySearchManager | null; error?: string; }> {
        this.logger.info("[JsonMemoryRuntime] getMemorySearchManager"+ params);
        return Promise.resolve({ manager: new JsonMemorySearchManager(this.store, this.logger) });
    }
    resolveMemoryBackendConfig(params: { cfg: OpenClawConfig; agentId: string; }): { backend: "builtin"; } | { backend: "qmd"; qmd?: { command?: string; }; } {
        this.logger.info("[JsonMemoryRuntime] resolveMemoryBackendConfig"+ params);
        return { backend: "builtin" };
    }
    closeMemorySearchManager?(params: { cfg: OpenClawConfig; agentId: string; }): Promise<void> {
        this.logger.info("[JsonMemoryRuntime] closeMemorySearchManager"+ params);
        return Promise.resolve();
    }
    closeAllMemorySearchManagers?(): Promise<void> {
        this.logger.info("[JsonMemoryRuntime] closeAllMemorySearchManagers");
        return Promise.resolve();
    }

    private readonly store = new JsonMemoryStore();

}

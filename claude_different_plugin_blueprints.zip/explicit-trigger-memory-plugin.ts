// explicit-trigger-memory-plugin.ts
//
// Approach: EXPLICIT TRIGGER + PLUGIN JUDGMENT
// The LLM decides *when* to call memory_write / memory_search — that part is
// ordinary tool-calling. But calling memory_write does NOT guarantee a save.
// The plugin's own shouldStore() logic makes the keep/discard decision.
//
// NOTE: `definePluginEntry`, `registerTool`, and the exact shape of `ctx`
// are based on the plugin-slot pattern OpenClaw documents for memory plugins.
// Check openclaw/plugin-sdk's current type definitions before wiring this up —
// field/method names may differ slightly by version.

import { definePluginEntry } from "openclaw/plugin-sdk/plugin-entry";

// ---------------------------------------------------------------------------
// 1. Storage backend — swap this out for your real system (vector DB, graph
//    store, hosted API, whatever). This file only cares about the interface.
// ---------------------------------------------------------------------------

interface MemoryItem {
  id: string;
  content: string;
  metadata: Record<string, unknown>;
  createdAt: string;
}

interface MemoryBackend {
  search(query: string, limit: number): Promise<MemoryItem[]>;
  get(id: string): Promise<MemoryItem | null>;
  save(content: string, metadata: Record<string, unknown>): Promise<MemoryItem>;
}

// Minimal in-memory stub so this file runs standalone during development.
// Replace with your real backend (e.g. a Postgres/pgvector client, a
// LanceDB table, a call to a hosted memory API).
class StubBackend implements MemoryBackend {
  private items: MemoryItem[] = [];

  async search(query: string, limit: number) {
    const q = query.toLowerCase();
    return this.items
      .filter((i) => i.content.toLowerCase().includes(q))
      .slice(0, limit);
  }

  async get(id: string) {
    return this.items.find((i) => i.id === id) ?? null;
  }

  async save(content: string, metadata: Record<string, unknown>) {
    const item: MemoryItem = {
      id: crypto.randomUUID(),
      content,
      metadata,
      createdAt: new Date().toISOString(),
    };
    this.items.push(item);
    return item;
  }
}

// ---------------------------------------------------------------------------
// 2. Judgment logic — this is YOUR memory system's intelligence.
//    The LLM offers content; this function decides if it's worth keeping.
//    Replace with whatever scoring/classification approach you want:
//    a rules engine, an importance-scoring model call, a dedup/similarity
//    check against existing memories, etc.
// ---------------------------------------------------------------------------

interface StoreDecision {
  store: boolean;
  reason: string;
  metadata?: Record<string, unknown>;
}

async function shouldStore(
  backend: MemoryBackend,
  content: string
): Promise<StoreDecision> {
  const trimmed = content.trim();

  // Example gate 1: reject trivially short or empty content
  if (trimmed.length < 8) {
    return { store: false, reason: "too short to be a useful memory" };
  }

  // Example gate 2: reject near-duplicates of something already stored
  const similar = await backend.search(trimmed, 3);
  const isDuplicate = similar.some(
    (item) => item.content.toLowerCase() === trimmed.toLowerCase()
  );
  if (isDuplicate) {
    return { store: false, reason: "duplicate of existing memory" };
  }

  // Example gate 3: your own importance heuristic / classifier call would
  // go here. Keep it cheap — this runs on every memory_write call.
  const importance = scoreImportance(trimmed);
  if (importance < 0.3) {
    return { store: false, reason: `importance ${importance} below threshold` };
  }

  return {
    store: true,
    reason: `importance ${importance}`,
    metadata: { importance },
  };
}

// Placeholder scorer — replace with real logic (keyword weighting, a small
// classifier call, recency/frequency signals, whatever fits your system).
function scoreImportance(content: string): number {
  const signalWords = ["prefer", "always", "never", "remember", "important"];
  const hits = signalWords.filter((w) => content.toLowerCase().includes(w));
  return Math.min(1, 0.2 + hits.length * 0.25);
}

// ---------------------------------------------------------------------------
// 3. Plugin registration
// ---------------------------------------------------------------------------

export default definePluginEntry({
  id: "explicit-trigger-memory",
  name: "Explicit Trigger Memory",
  description: "Memory plugin where the agent offers content and the plugin decides whether to keep it",
  kind: "memory", // claims the exclusive memory slot — memory-core is not loaded

  register(api) {
    const backend: MemoryBackend = new StubBackend();

    api.registerTool({
      name: "memory_search",
      description: "Search stored memories relevant to a query",
      handler: async (args: { query: string; limit?: number }) => {
        const results = await backend.search(args.query, args.limit ?? 5);
        return { results };
      },
    });

    api.registerTool({
      name: "memory_get",
      description: "Fetch a specific memory item by id",
      handler: async (args: { id: string }) => {
        const item = await backend.get(args.id);
        return { item };
      },
    });

    api.registerTool({
      name: "memory_write",
      description:
        "Offer information that may be worth remembering. The memory system decides whether to actually store it — a call here is not guaranteed to result in a save.",
      handler: async (args: { content: string }) => {
        const decision = await shouldStore(backend, args.content);

        if (!decision.store) {
          return { stored: false, reason: decision.reason };
        }

        const item = await backend.save(args.content, decision.metadata ?? {});
        return { stored: true, id: item.id, reason: decision.reason };
      },
    });
  },
});

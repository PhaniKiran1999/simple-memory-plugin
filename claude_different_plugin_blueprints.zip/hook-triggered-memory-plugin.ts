// hook-triggered-memory-plugin.ts
//
// Approach: HOOK-TRIGGERED + PLUGIN JUDGMENT
// The plugin runs on every turn regardless of what the model chooses to do.
// - Before the LLM call: an auto-recall hook searches memory and injects
//   relevant results into context. The LLM never calls a tool for this.
// - After the LLM call: an auto-capture hook reads the finished turn and
//   decides, on its own, what's worth storing.
//
// This still keeps optional explicit tools (memory_search / memory_get) for
// cases where the agent wants to look something up mid-reasoning, but the
// core recall/capture behavior does NOT depend on the model calling them.
//
// NOTE: hook names (onBeforeModelCall / onAfterTurn) and the
// prependSystemContext mechanism are illustrative of the pattern
// third-party memory plugins use (e.g. auto-recall via system-context
// injection, auto-capture via post-turn transcript scanning). Confirm the
// exact hook lifecycle names against openclaw/plugin-sdk's current API
// before wiring this up — treat this as a structural template, not a
// verified-against-source implementation.

import { definePluginEntry } from "openclaw/plugin-sdk/plugin-entry";

// ---------------------------------------------------------------------------
// 1. Storage backend (same interface as the explicit-trigger version)
// ---------------------------------------------------------------------------

interface MemoryItem {
  id: string;
  content: string;
  metadata: Record<string, unknown>;
  createdAt: string;
}

interface MemoryBackend {
  search(query: string, limit: number): Promise<MemoryItem[]>;
  get(id: string): Promise<MemoryItem | null>;
  save(content: string, metadata: Record<string, unknown>): Promise<MemoryItem>;
}

class StubBackend implements MemoryBackend {
  private items: MemoryItem[] = [];

  async search(query: string, limit: number) {
    const q = query.toLowerCase();
    return this.items
      .filter((i) => i.content.toLowerCase().includes(q))
      .slice(0, limit);
  }

  async get(id: string) {
    return this.items.find((i) => i.id === id) ?? null;
  }

  async save(content: string, metadata: Record<string, unknown>) {
    const item: MemoryItem = {
      id: crypto.randomUUID(),
      content,
      metadata,
      createdAt: new Date().toISOString(),
    };
    this.items.push(item);
    return item;
  }
}

// ---------------------------------------------------------------------------
// 2. Judgment logic for capture — same idea as shouldStore() before, but now
//    it runs against a whole turn's transcript instead of one offered string.
// ---------------------------------------------------------------------------

interface TurnRecord {
  userMessage: string;
  assistantMessage: string;
}

interface ExtractedFact {
  content: string;
  metadata: Record<string, unknown>;
}

// Your extraction/judgment logic: decide what (if anything) from this turn
// is worth persisting. Could be rule-based, could call a small classifier,
// could run a structured-extraction prompt against your own model — this
// plugin owns that decision, not the agent.
async function extractWorthyFacts(turn: TurnRecord): Promise<ExtractedFact[]> {
  const facts: ExtractedFact[] = [];
  const signalWords = ["prefer", "always", "never", "my name is", "i live"];

  const combined = `${turn.userMessage}`.toLowerCase();
  const hit = signalWords.find((w) => combined.includes(w));

  if (hit) {
    facts.push({
      content: turn.userMessage.trim(),
      metadata: { source: "auto-capture", triggeredBy: hit },
    });
  }

  return facts;
}

// ---------------------------------------------------------------------------
// 3. Plugin registration
// ---------------------------------------------------------------------------

export default definePluginEntry({
  id: "hook-triggered-memory",
  name: "Hook Triggered Memory",
  description: "Memory plugin that recalls before and captures after every turn, independent of tool calls",
  kind: "memory",

  register(api) {
    const backend: MemoryBackend = new StubBackend();

    // Optional explicit tools — still useful for on-demand lookups mid-reply,
    // but NOT what drives the core recall/capture behavior below.
    api.registerTool({
      name: "memory_search",
      description: "Manually search stored memories relevant to a query",
      handler: async (args: { query: string; limit?: number }) => {
        const results = await backend.search(args.query, args.limit ?? 5);
        return { results };
      },
    });

    api.registerTool({
      name: "memory_get",
      description: "Fetch a specific memory item by id",
      handler: async (args: { id: string }) => {
        const item = await backend.get(args.id);
        return { item };
      },
    });

    // --- AUTO-RECALL --------------------------------------------------
    // Fires before the LLM sees the user's message. No tool call involved —
    // results get injected straight into context.
    api.onBeforeModelCall(async (ctx) => {
      const userMessage = ctx.latestUserMessage;
      const relevant = await backend.search(userMessage, 5);

      if (relevant.length === 0) return;

      const contextBlock = relevant
        .map((item) => `- ${item.content}`)
        .join("\n");

      ctx.prependSystemContext(
        `Relevant memories:\n${contextBlock}`
      );
    });

    // --- AUTO-CAPTURE ---------------------------------------------------
    // Fires after the LLM has replied. Reads the finished turn and decides,
    // via the plugin's own logic, what (if anything) to store.
    api.onAfterTurn(async (ctx) => {
      const turn: TurnRecord = {
        userMessage: ctx.latestUserMessage,
        assistantMessage: ctx.latestAssistantMessage,
      };

      const facts = await extractWorthyFacts(turn);
      for (const fact of facts) {
        await backend.save(fact.content, fact.metadata);
      }
    });
  },
});
